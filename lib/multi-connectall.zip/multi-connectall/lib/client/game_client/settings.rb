
### 
# Settings used by game client
# Can be changed by user depending on goal

SCREEN_WIDTH = 400
SCREEN_HEIGHT = 533

SERVER = '192.168.0.5'                       
PORT = 8080                                     
NAME = Randgen.first_name(length: 5 + rand(5))  

