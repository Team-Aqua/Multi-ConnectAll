module Controllers
  class Controller

    ##
    # Abstract interface for controllers

    include AbstractInterface
  end
end