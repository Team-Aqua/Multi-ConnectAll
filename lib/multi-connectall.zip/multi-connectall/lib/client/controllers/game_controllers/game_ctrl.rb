module Controllers
  class GameCtrl
    attr_accessor :view, :window, :game_state_model, :alert_view, :state, :data_loaded, :data_saved

    ## 
    # Main controller for game interactions
    # Uses the game_state_model as reference to 
    # identify actions and processes to take.

    def initialize(window, game_state_model)
      @window = window
      @game_state_model = game_state_model
      @view = Views::GameView.new(@window, self, @game_state_model)
      @menu_click_sound = Gosu::Sample.new(@window, "assets/sounds/menu_click.mp3")
      @win_sound = Gosu::Sample.new(@window, "assets/sounds/cheer_win.mp3")
      
      if @game_state_model::game_mode != :pvai
        @alert_view = Views::WaitingAlertView.new(@window, self)
      else
        @alert_view = nil
      end

      @player_moved = false
      @data_loaded = false
      @skip_run = false
      @skip_pos = 0
      @concede_run = false
      @concede_pos = 0
      @data_saved = false

      GameControllerContracts.invariant(self)
    end

    def load_save
      write_message(['setup_save', @game_state_model.name].join('|'))
    end

    def reconstruct_grid(gridipt)
      gridData = gridipt.split("&")
      # puts "GridData: #{gridData}"
      grid = []
      (0..7).each { |y|
        row = []
        (0..7).each { |x|
            row.push(gridData[(y * 8) + x].to_i)
          }
          grid.push(row)
        }
      return grid
    end

    ## 
    # Resets match, clears open alertviews
    # Forces model resets before resetting game.
    # Inputs: none
    # Outputs: none

    def reset_match
      GameControllerContracts.invariant(self)
      @menu_click_sound.play(0.7, 1, false)
      @game_state_model::state = :active
      @game_state_model::grid.reset
      @game_state_model::player_turn_state = 0
      @view::control.build_red_grid
      alert_close
      GameControllerContracts.post_reset_match(self)
    end

    ##
    # Gosu implementation
    # Inputs: none
    # Outputs: none

    def button_down(key)
    end

    ##
    # Gosu implementation
    # Inputs: none
    # Outputs: none

    def draw
      @view.draw
      if @alert_view != nil
        @alert_view.draw
      end
    end

    ##
    # Gosu implementation
    # Inputs: none
    # Outputs: none

    def update
      @view.update
      if @alert_view != nil
        @alert_view.update
      else
        if @player_moved == false
          move_block
        end
      end
      if @game_state_model::game_mode != :pvai
        toggle_multiplayer_controls
        begin
        send_sync_message
        read_message
        rescue
        end
      end
    end

    ##
    # Logic for placing block
    # Refactored for multiplayer functionality

    def move_block(self_proc = false)
      @player_moved = @game_state_model::players[@game_state_model::player_turn_state].make_move{ |x, player_num, player_color, delay|
        @view::control.disable_control_on_player
        @view::grid.animate_tile_drop(x, player_color, delay) {
          @view::control.enable_control_on_player
          @game_state_model::grid.add_tile(x, player_num);
          check_winner_winner;  
          @view::control.disable_control_on_AI;
          @game_state_model.toggle_player_turn_state;
          @view::control.check_available; 
          if self_proc == false && @game_state_model::game_mode != :pvai
            @window.client_network_com.move(x)
          end
          @player_moved = false; 
          @game_state_model::turn_count += 1
          }
        }
    end

    ## 
    # Sends signal to server depending on what is required
    # For initial sync - load is required
    # For in-game - wait is required

    def send_sync_message
      if @data_loaded == false && @data_saved == false
        write_message('load')
      elsif @data_loaded == false && @data_saved == true
        write_message('load_save')
      else
        write_message('wait')
      end
    end

    ##
    # Generic write signal
    # Used for sending messages to server
    
    def write_message(message)
      @window.client_network_com.send_message(message)
    end

    ##
    # Reads server message
    # Possible states:
    # 'game' - standard game logic - either new move or old move placed.
    # 'load' - new game logic - loads other player info

    def read_message
      if data = @window.client_network_com.read_message ## IMPORTANT: blocks until message is received - aka 'heartbeat'
        data = data.split('|')
        if data && !data.empty?
          if data[0] == "game"
            position = data.last
            position = position.split('%')
            if (position[0] == 'A' and @game_state_model::player_role == 1) or (position[0] == 'B' and @game_state_model::player_role == 0)
                
              ###
              # SKIP Processing
              # Used if valid skip information was passed to user

              if position[1] == 'S'
                if (@game_state_model::turn_count < (data.length - 7)) 
                  @view::control.enable_control_on_player
                  skip_logic
                  return
                else 
                  return
                end

              ###
              # CONCEDE Processing
              # Used if valid concede information was passed to user
              
              elsif position[1] == 'C' 
                if (@game_state_model::turn_count < (data.length - 7))
                  concede_logic('other')
                  return
                else 
                  return
                end

              ###
              # SAVE Processing
              # Used if valid 'save data' information was passed to user

              elsif position[1] == 'V' 
                save_logic
                return

              ###
              # MOVE Processing
              # Used to process new move passed to user

              else
                ypos = @game_state_model::grid.column_depth(position[1].to_i)
                if ypos > position[2].to_i and @player_moved == false
                  @player_moved = true;
                  xpos = position[1].to_i
                  @game_state_model::players[@game_state_model::player_turn_state].set_move(xpos)
                  move_block(self_proc: true)
                end 
              end
            end

          ###
          # loadsave
          # used to interpret save game information 
          # reloads saved game

          elsif data[0] == "loadsave"
            @data_loaded = true
            @alert_view = nil
            grid = data[9]
            turn_state = data[8].to_i 
            @game_state_model::players[0]::name = data[1]
            @game_state_model::players[1]::name = data[2]
            @game_state_model::players[0]::player_color = data[3]
            @game_state_model::players[1]::player_color = data[4]
            if data[7] == 'classic'
              @game_state_model::game_type = :classic
            elsif data[7] == 'otto'
              @game_state_model::game_type = :otto
            end
            if @game_state_model::game_type == :classic
              @game_state_model::game_mode_logic = GameLogic::ClassicRules.new(@game_state_model)
            else
              @game_state_model::game_mode_logic = GameLogic::OttoRules.new(@game_state_model)
            end
            @view::grid::model = @game_state_model
            @view::header::game_state_model = @game_state_model
            @view::header.set_tiles
            @view::grid.set_tiles
            if @game_state_model::name == @game_state_model::players[0]::name
              @game_state_model::player_role = 0
            elsif @game_state_model::name == @game_state_model::players[1]::name
              @game_state_model::player_role = 1
            else 
              window.close
            end
            @game_state_model::grid.setGrid(reconstruct_grid(grid))
            if turn_state == 1
              @game_state_model.toggle_player_turn_state;
            end

          ###
          # load
          # used to interpret player information 
          # passed on new game

          elsif data[0] == "load"
            @data_loaded = true
            @alert_view = nil
            if @game_state_model::player_role == 0
              @game_state_model::players[1]::name = data[2]
              @game_state_model::players[1]::player_color = data[4] 
              @game_state_model::players[1]::score = data[6].to_i
            elsif @game_state_model::player_role == 1
              @game_state_model::players[0]::name = data[1]
              @game_state_model::players[0]::player_color = data[3] 
              @game_state_model::players[0]::score = data[5].to_i
            end
          end
        end
      end
    end

    ##
    # Sets multiplayer functions depending on whose turn it is

    def toggle_multiplayer_controls
      if (@game_state_model::player_turn_state != @game_state_model::player_role) 
        if (@view::control.control_disabled == false)
          @view::control.disable_control_on_player
        end
      elsif (@game_state_model::player_turn_state == @game_state_model::player_role) 
        if (@view::control.control_disabled == true)
          @view::control.enable_control_on_player
        end
      end
    end

    ##
    # Checks for winner given game state, or for tie
    # If winner or tie is present, handles processes
    # Inputs: none
    # Outputs: none

    def check_winner_winner
      @game_state_model::game_mode_logic.check_for_winner
      if @game_state_model::state == :win
        @win_sound.play(0.7, 1, false)
        @game_won = true
        @alert_view = Views::WinAlertView.new(@window, self, @game_state_model::players[@game_state_model::winner].player_color)
        @game_state_model::players[@game_state_model::winner].increment_win_score
        if @game_state_model::winner == @game_state_model::player_role
          @window.client_network_com.send_win
        else
          @window.client_network_com.send_loss
        end
      end  
      if @game_state_model::state == :tie
        @win_sound.play(0.7, 1, false)
        @game_won = true
        @alert_view = Views::WinAlertView.new(@window, self, 'tie')
        @window.client_network_com.send_tie
      end 
    end

    ##
    # Gosu implementation
    # Forces alertview check if alertview is open; prevents inputs outside of alertview if true
    # Inputs: none
    # Outputs: none

    def clicked
      if @alert_view != nil
        @alert_view.clicked
      else
        @view.clicked
      end
    end

    ##
    # Places tile on grid,
    # Handles processing up to that point.
    # Inputs: x position
    # Outputs: none

    def place_tile(x)
      GameControllerContracts.invariant(self)
      @view::grid.animate_tile_drop(x, @game_state_model::players[player_turn].player_color, delay){@game_state_model::grid.add_tile(x, player_turn)}
      GameControllerContracts.invariant(self)
    end

    ##
    # Checks if block input is viable
    # Inputs: x position
    # Outputs: none 

    def control_button_click(x)
      GameControllerContracts.invariant(self)
      GameControllerContracts.pre_button_click(self, x)
      @view::control.disable_control_on_AI
      @game_state_model::players[@game_state_model::player_turn_state]::set_move(x)
      @view::control.check_available
      GameControllerContracts.invariant(self)
    end

    ##
    # Handles processing for 'skip' button clicked
    # If skipping is available, that player's turn is skipped
    # N/A on computer's turn
    # Inputs: none
    # Outputs: none

    def skip_button_click
      GameControllerContracts.invariant(self)
      if @skip_run == false
        @skip_run = true
        if (@game_state_model::players[@game_state_model::player_turn_state].ai == nil) and (@game_state_model::player_turn_state == @game_state_model::player_role) # if it isn't an ai currently playing
          write_message(['skip', @game_state_model::player_role].join('|'))
          skip_logic
          @menu_click_sound.play(0.7, 1, false)
        end
        @skip_run = false
      end
      GameControllerContracts.invariant(self)
    end     

    ##
    # Separated skip logic 
    # Used for server input of 'skip' received 

    def skip_logic
      @game_state_model.toggle_player_turn_state
      @game_state_model::turn_count += 1
    end

    ##
    # Separated save logic 
    # Used for server input of 'save' received 

    def save_logic
      GameControllerContracts.invariant(self)
      @alert_view = @help_view = Views::SaveAlertView.new(@window, self)
      @menu_click_sound.play(0.7, 1, false)
      GameControllerContracts.invariant(self)
    end

    ##
    # Handles processing for 'concede' button clicked
    # If conceding is available, that player loses
    # N/A on computer's turn
    # Inputs: none
    # Outputs: none

    def concede_button_click
      GameControllerContracts.invariant(self)
      if @game_state_model::players[@game_state_model::player_turn_state].ai == nil # if it isn't an ai currently playing
        concede_logic('self')
        write_message(['concede', @game_state_model::player_role].join('|'))
        @menu_click_sound.play(0.7, 1, false)
      end
      GameControllerContracts.invariant(self)
    end

    ##
    # Separated concede logic 
    # Used for server input of 'concede' received 

    def concede_logic(lost)
      @game_won = true
      if (lost == 'self')
        if @window.client_network_com != nil
          @window.client_network_com.send_loss
        end
        if (@game_state_model::player_role == 0)
          winner = 1
        else
          winner = 0
        end
      else 
        winner = @game_state_model::player_role
        if @window.client_network_com != nil
          @window.client_network_com.send_win
        end
      end
      @alert_view = Views::WinAlertView.new(@window, self, @game_state_model::players[winner].player_color)
      @game_state_model::players[winner].increment_win_score
      @game_state_model::turn_count += 1
    end

    ##
    # Handles processing for 'reset' button clicked
    # Rebuilds grid and buttons
    # Inputs: none
    # Outputs: none

    def reset_button_click
      GameControllerContracts.invariant(self)
      @game_state_model::grid.reset
      @view::control.build_red_grid
      GameControllerContracts.invariant(self)
    end

    ## 
    # Opens help alert view for user
    # Inputs: none
    # Outputs: none

    def question_button_click
      GameControllerContracts.invariant(self)
      @alert_view = @help_view = Views::HelpAlertView.new(@window, self)
      @menu_click_sound.play(0.7, 1, false)
      GameControllerContracts.invariant(self)
    end

    ##
    # Opens alert for exit
    # Allows user to claritfy for exit or save

    def quit_alert
      GameControllerContracts.invariant(self)
      @alert_view = @help_view = Views::ExitAlertView.new(@window, self)
      @menu_click_sound.play(0.7, 1, false)
      GameControllerContracts.invariant(self)
    end

    ##
    # Saves current game to server
    # Terminates existing gameplay

    def save_game
      write_message(['save', @game_state_model::name, @game_state_model::players[0].name, @game_state_model::players[1].name, @game_state_model::players[0].player_color, @game_state_model::players[1].player_color, @game_state_model::grid.getGrid.join('&'), @game_state_model::player_turn_state, @game_state_model::game_type].join('|'))
    end

    ##
    # Specialised 'return to menu' functionality
    # If singleplayer, return to offline menu
    # If multiplayer, return to online menu

    def return_to_spec_menu
      if @game_state_model::game_mode != :pvp
        @window.return_to_spec_menu
      else
        @window.return_to_type_menu
      end
    end

    ##
    # Handles the 'X' button in game header

    def handle_quit
      if @game_state_model::game_mode == :pvai
        @window.close
      else
        quit_alert
      end
    end

    ##
    # Concedes if player selects 'exit'

    def force_quit
      concede_logic('self')
      if @window.client_network_com != nil
        write_message(['concede', @game_state_model::player_role].join('|'))
      end
      @window.close
    end

    ##
    # Loads stats
    # Used for player_header to fill stat information

    def get_player_stats(name)
      write_message(['load_stats', name].join('|'))
      return @window.client_network_com.read_message
    end

    ##
    # Closes any alert view present
    # Inputs: none
    # Outputs: none

    def alert_close
      GameControllerContracts.invariant(self)
      @menu_click_sound.play(0.7, 1, false)
      @alert_view = nil
      GameControllerContracts.invariant(self)
    end

    ##
    # Closes window
    # Currently unused
    # Inputs: none
    # Outputs: none

    def cancel_button_click
      GameControllerContracts.invariant(self)
      @window.close
    end

  end
end