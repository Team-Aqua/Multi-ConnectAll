SCREEN_WIDTH = 400
SCREEN_HEIGHT = 533

SERVER = '127.0.0.1'                        # ARGV[0] || 192.168.0.5
PORT = 8080                                   # ARGV[1] || 
NAME = Randgen.first_name(length: 5 + rand(5))  # ARGV[2] || 

