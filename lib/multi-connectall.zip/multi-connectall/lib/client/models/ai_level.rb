module Models
  class AILevel
    attr_accessor :level
    ## 
    # Identifies AI level

    def initialize
      @level = 0
    end

  end
end