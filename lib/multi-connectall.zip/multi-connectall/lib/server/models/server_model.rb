module Models
  class ServerModel

    def initialize()
      @otto_queue = []
      @classic_queue = []
      @active_games = []
      @online_users = []
    end
  end
end